<template>
  <el-table
    :data="tableData3"
    height="500"
    border
    style="width: 100%">
    <el-table-column
      prop="id"
      label="编号"
       >
    </el-table-column>
    <el-table-column
      prop="name"
      label="名字"
       >
    </el-table-column>
    <el-table-column
      prop="detail"
      label="任务"
	   >
    </el-table-column>
	<el-table-column
	prop="createdAt"
	label="任务创建时间"
	 >
	</el-table-column>
	<el-table-column
	prop="finishedAt"
	label="任务应完成时间"
	 >
	</el-table-column>
	<el-table-column
	prop="state"
	label="状态"
	 >
	 <template slot-scope="scope">
	 <el-switch
  v-model="value2"
  active-color="#13ce66"
  inactive-color="#ff4949">
</el-switch>
</template>
	</el-table-column>
	<el-table-column
	prop="memo"
	label="备注"
	 >
	</el-table-column>
	<el-table-column
	prop=""
	label="操作"
	>
	 <template slot-scope="scope">
        <el-button
          @click="deleteRow(scope.row,scope.$index, tableData3)"
          type="text"
          size="small">
          移除
        </el-button>
      </template>
	</el-table-column>
  </el-table>
</template>

<script>
  export default {
    data() {
      return {
        tableData3: [
		],
		 value1: true,
        value2: true
      }
    },created() {
		const that = this;
    	fetch('http://localhost:8081/todo')
		.then(function(res){
			return res.json();
		}).then(function(data){
			that.tableData3=data;
		})
    },methods:{
			
			deleteRow(index,row ,rows) {
				this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
         fetch('http://localhost:8081/todo/del?id='+index.id,{method:"get"});
         	rows.splice(row, 1);
         		this.$message({
         	message: `删除成功`
         	});
					})

         }
      
				
       
      }
	
  }
  
</script>

