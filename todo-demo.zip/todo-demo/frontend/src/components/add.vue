<template>
	<div>
		<h1>添加操作</h1>
<el-form ref="form" label-width="80px">
  <el-form-item label="姓名">
    <el-input v-model="name" placeholder="请输入姓名" ></el-input>
  </el-form-item>
  <el-form-item label="任务" >
    <el-input type="textarea" v-model="detail" ></el-input>
  </el-form-item>
  <el-form-item label="备注" >
  <el-input type="textarea" v-model="memo" ></el-input>
  </el-form-item>
  <el-form-item>
    <el-button type="primary" @click="addTodo">添加</el-button>
    <el-button  @click="reset">重置</el-button>
  </el-form-item>
</el-form>
</div>
</template>

<script>
	export default {
		data() {
			return {
				name: '',
				detail: '',
				memo: ''
			}
		},
		methods: {
			reset() {
				this.name = '';
				this.detail = '';
				this.memo = '';
				this.$message({
              message: `重置成功`
            });
			},
			addTodo() {
				var se = this;
				if (this.name == '' || this.detail == '' || this.date == '') {
					 this.$alert('不能为空', '提示');
					return false;
				}

				var subData = {
					name: this.name,
					detail: this.detail,
					memo: this.memo
				};


				fetch('http://localhost:8081/todo', {
					method: 'post',
					headers: {
						"Content-Type": "application/json",
						"Accept": "application/json"
					},
					body: JSON.stringify(subData)
				}).then(function(resp) {
					resp.json().then((data) => {
						window.location.href = 'http://localhost:8080/';
					});
					se.reset();
				});


			}
		}
	}
</script>
